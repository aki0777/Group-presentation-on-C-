﻿namespace HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a new instance of HashTable with key-value pair string-string
            HashTable<string, string> hashTable = new HashTable<string, string>();

            hashTable.Add("One", "Akhilesh"); //adding new key(personOne) with a new value(Akhilesh)
            hashTable.Add("Two", "Jeshwan"); //adding new key(personTwo) with a new value(Jeshwan)
            hashTable.Add("Three", "Milesh");  //adding new key(personThree) with a new value(Milesh)

            // Get the value of key "b"
            Console.WriteLine(hashTable.Get("One")); // getting the value(Akhilesh) of key personOne

            // Remove key "a"
            hashTable.Remove("One");  // removing the value(Akhilesh) and key of personOne

            foreach (KeyValuePair<string, string> item in hashTable)
            {
                Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
            }

            // Create a new instance of HashTable with key-value pair int-double
            HashTable<int, double> anotherHashTable = new HashTable<int, double>();
            anotherHashTable.Add(1, 3.14);   //adding new key(1) with a new value(3.14)
            anotherHashTable.Add(2, 2.718);   //adding new key(2) with a new value(2.718)
            anotherHashTable.Add(3, 4.8974);   //adding new key(3) with a new value(4.8974)

            // Get the value of key 1
            Console.WriteLine(anotherHashTable.Get(1));  // getting the value(3.14) of key 1

            // check if the hashtable contains the key
            Console.WriteLine(anotherHashTable.ContainsKey(3));

            //check if the hashtable contains the value
            Console.WriteLine(anotherHashTable.ContainsValue(5.875));

            // Remove key 2
            anotherHashTable.Remove(2); // removing the value(2.718) and key of 2
            // anotherHashTable.Remove(3); // This will throw an exception

            foreach (KeyValuePair<string, string> item in hashTable)
            {
                Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
            }  //output the hashtable into string

            anotherHashTable.Clear();  // clears the entire hashtable
            
        }
    }
}
