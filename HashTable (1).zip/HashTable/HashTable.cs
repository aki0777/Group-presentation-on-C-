﻿using System.Collections;

namespace HashTable
{
    class HashTable<K, V> : IEnumerable<KeyValuePair<K, V>>
    {
        private Dictionary<K, V> hashTable;

        public HashTable()
        {
            hashTable = new Dictionary<K, V>();
        }

        // Adds a key-value pair to the hash table
        public void Add(K key, V value)
        {
            hashTable.Add(key, value);
        }

        // Returns the value of the given key
        public V Get(K key)
        {
            if (hashTable.ContainsKey(key))
            {
                return hashTable[key];
            }

            throw new Exception("Key not found");
        }

        // Removes a key-value pair from the hash table
        public void Remove(K key)
        {
            // Throw an exception if the key is not found
            if (!hashTable.Remove(key))
            {
                throw new Exception("Key not found");
            }
        }

        // Clears the hash table
        public void Clear()
        {
            hashTable.Clear();
        }

        // Checks if the hash table contains a key
        public bool ContainsKey(K key)
        {
            return hashTable.ContainsKey(key);
        }

        // Checks if the hash table contains a value
        public bool ContainsValue(V value)
        {
            return hashTable.ContainsValue(value);
        }

        // Returns a string representation of the hash table
        public override string ToString()
        {
            return string.Join(", ", hashTable);
        }

        public IEnumerator<KeyValuePair<K, V>> GetEnumerator()
        {
            foreach (var kvp in hashTable)
            {
                yield return kvp;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}